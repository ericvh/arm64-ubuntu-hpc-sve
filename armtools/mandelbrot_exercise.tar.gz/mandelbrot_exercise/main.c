// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
//        (C) COPYRIGHT 2017 ARM Limited or its affiliates.
//            ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Author: Mbou Eyole <Mbou.Eyole@arm.com>

#include<stdio.h>
#include<stdlib.h>

void Mandelbrot (unsigned int * OutputData, int SizeX, int SizeY, int max, float xscale, float yscale, float xstart, float ystart){
  int i;
  int j;
  float x;
  float y;
  float x0;
  float y0;
  float xtemp;
  int iteration;
  
  for(i=0;i<SizeX;i++){
    x0 = xstart + i*xscale;
    for(j=0;j<SizeY;j++){ 
       y0 = ystart + j*yscale;
       x = 0.0;
       y = 0.0;
       iteration = 0;
       while ((x*x + y*y < 4)  &&  (iteration < max)) {
          xtemp = x*x - y*y + x0;
          y = 2*x*y + y0;
          x = xtemp;
          iteration++;
	  //printf("%d : %d  : %f : %f\n", j, iteration, x, y);
       }
       OutputData[i*SizeY+j] = iteration;
    }
  }
}

#ifdef SVE_PRESENT
extern void Mandelbrot_simd (unsigned int * OutputData, int SizeX, int SizeY, int max_iteration, float xscale, float yscale, float xstart, float ystart);
#endif


int main(void){

    const int sizeX = 100;
    const int sizeY = 100;
    const int max_iteration = 1000;
    int i;
    int j;
    unsigned int * outputdata = (unsigned int*)malloc(sizeX*sizeY*sizeof(unsigned int));
    float x0;
    float y0;
    
    float xscale = ((3.5)/(float)sizeX);
    float yscale = ((2.0)/(float)sizeY);
    float xstart = -2.5;
    float ystart = -1.0;
    #ifndef SVE_PRESENT
    Mandelbrot(outputdata, sizeX, sizeY, max_iteration, xscale, yscale, xstart, ystart);
    #else
    Mandelbrot_simd(outputdata, sizeX, sizeY, max_iteration, xscale, yscale, xstart, ystart);
    #endif

    for(i=0;i<sizeX;i++){
      x0 = xstart + i*xscale;
      for(j=0;j<sizeY;j++){
        y0 = ystart + j*yscale;
        printf("%le\t%le\t%le\n",(double)x0,(double)y0,(double)outputdata[i*sizeY+j]);  
      }
    }

    free(outputdata);
}



